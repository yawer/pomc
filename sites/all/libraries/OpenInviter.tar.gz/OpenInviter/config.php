<?php
$openinviter_settings=array(
'username'=>"syamkumarc", 'private_key'=>"1b38ca64ddcf369babb0976c89c39fe9", 'cookie_path'=>"/tmp", 'message_body'=>"You are invited to wced-staging.azri.de", 'message_subject'=>" is inviting you to wced-staging.azri.de", 'transport'=>"curl", 'local_debug'=>"on_error", 'remote_debug'=>"", 'hosted'=>"", 'proxies'=>array(),
'stats'=>"", 'plugins_cache_time'=>"1800", 'plugins_cache_file'=>"oi_plugins.php", 'update_files'=>"1", 'stats_user'=>"", 'stats_password'=>"");
?>